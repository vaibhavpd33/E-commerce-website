1.Open the E-commerce folder on the cmd.
2.Create a virtual environment.
	> python3 -m venv Applibs
3.Activate Virtual environment 
	> Applibs\Scripts\activate
4.Install required packages using requirement.txt
	> pip install -r requirement.txt
5.run the program using (run.py is file name)
 	> python run.py
